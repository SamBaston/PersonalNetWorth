# Wealth Tracker

A personal wealth tracking web application.

## Project Structure

```
wealth-tracker/
├── data/
│   └── wealth.json          # JSON data store (accounts, transactions, settings)
├── public/
│   ├── index.html           # Main dashboard page
│   ├── style.css            # App styles
│   └── app.js               # Frontend JS (API calls, rendering)
├── server/
│   ├── server.js            # Express server entry point
│   └── routes/
│       └── api.js           # REST API route handlers
├── package.json
└── README.md
```

## Getting Started

```bash
# Install dependencies
npm install

# Start the server
npm start

# For development with auto-reload
npm run dev
```

Open http://localhost:3000 in your browser.

## API Endpoints

| Method | Endpoint              | Description                        |
|--------|-----------------------|------------------------------------|
| GET    | /api/summary          | Net worth summary + breakdown      |
| GET    | /api/accounts         | List all accounts                  |
| GET    | /api/accounts/:id     | Get single account                 |
| POST   | /api/accounts         | Create account                     |
| PUT    | /api/accounts/:id     | Update account                     |
| DELETE | /api/accounts/:id     | Delete account                     |
| GET    | /api/transactions     | List transactions (?accountId=)    |
| POST   | /api/transactions     | Add transaction (updates balance)  |
| GET    | /api/settings         | Get app settings                   |
| PUT    | /api/settings         | Update settings                    |

## Data Shape

All data is stored in `data/wealth.json` with three top-level keys:
- `accounts` — array of account objects
- `transactions` — array of transaction objects
- `settings` — app-level settings (currency, theme, etc.)
